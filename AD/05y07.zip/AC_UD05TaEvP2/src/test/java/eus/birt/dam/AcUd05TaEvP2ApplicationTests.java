package eus.birt.dam;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AcUd05TaEvP2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
