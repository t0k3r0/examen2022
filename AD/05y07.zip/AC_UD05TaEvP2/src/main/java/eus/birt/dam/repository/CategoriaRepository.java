package eus.birt.dam.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import eus.birt.dam.domain.Categoria;

public interface CategoriaRepository extends JpaRepository<Categoria, Integer>{

}
