package eus.birt.dam;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AcUd05TaEvP2Application {

	public static void main(String[] args) {
		SpringApplication.run(AcUd05TaEvP2Application.class, args);
	}

}