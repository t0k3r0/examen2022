package eus.birt.dam;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class Ud7ApiRestMongodbApplication {
	
	  public static void main(String[] args) {
		  SpringApplication.run(Ud7ApiRestMongodbApplication.class, args);
	}
}
