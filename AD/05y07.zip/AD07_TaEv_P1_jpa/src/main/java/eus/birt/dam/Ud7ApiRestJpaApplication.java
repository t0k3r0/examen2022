package eus.birt.dam;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ud7ApiRestJpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(Ud7ApiRestJpaApplication.class, args);
	}

}
