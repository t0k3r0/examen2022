package eus.birt.dam.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import eus.birt.dam.domain.University;

public interface UniversityRepository extends JpaRepository<University, Integer>{

}
