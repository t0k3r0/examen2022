package eus.birt.dam.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import eus.birt.dam.domain.Instructor_Detail;

public interface Instructor_DetailRepository extends JpaRepository<Instructor_Detail, Integer>{

}
